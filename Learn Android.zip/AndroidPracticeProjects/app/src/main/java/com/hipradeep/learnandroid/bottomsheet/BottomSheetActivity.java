package com.hipradeep.learnandroid.bottomsheet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.hipradeep.learnandroid.R;

public class BottomSheetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_sheet);
    }
}